" perl plugins


" node plugins


" python3 plugins
call remote#host#RegisterPlugin('python3', '/home/ivan/.config/nvim-pde-local/lazy/neotemplate.nvim/rplugin/python3/nvim-cheetah-python-plugin.py', [
      \ {'sync': v:false, 'name': 'Template', 'type': 'command', 'opts': {'complete': 'customlist,CompleteTemplates', 'nargs': '*', 'range': ''}},
     \ ])
call remote#host#RegisterPlugin('python3', '/home/ivan/.config/nvim-pde-local/lazy/vim-pythonx/rplugin/python3/plugin.py', [
      \ {'sync': v:true, 'name': 'PythonxJavaChooseImport', 'type': 'function', 'opts': {}},
      \ {'sync': v:true, 'name': 'PythonxCocDiagnosticFirst', 'type': 'function', 'opts': {}},
      \ {'sync': v:true, 'name': 'PythonxCocDiagnosticNext', 'type': 'function', 'opts': {}},
     \ ])


" ruby plugins


