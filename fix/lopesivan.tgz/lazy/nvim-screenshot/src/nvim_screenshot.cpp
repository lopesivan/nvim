#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <functional>
#include <png.h>
#include <string>
#include <vector>

static std::string build_output_path(const char* save_dir)
{
    std::string dir;

    if(save_dir && std::strlen(save_dir) > 0)
    {
        dir = save_dir;
    }
    else
    {
        const char* home = std::getenv("HOME");
        if(!home)
            home = "/tmp";
        dir = std::string(home) + "/screenshots";
    }

    std::time_t now = std::time(nullptr);
    char        ts[32];
    std::strftime(
        ts, sizeof(ts), "%Y%m%d_%H%M%S", std::localtime(&now));

    return dir + "/nvim_" + ts + ".png";
}

static bool write_png(const std::string&          path,
                      int                         width,
                      int                         height,
                      const std::vector<uint8_t>& pixels)
{
    FILE* fp = std::fopen(path.c_str(), "wb");
    if(!fp)
        return false;

    png_structp png = png_create_write_struct(
        PNG_LIBPNG_VER_STRING, nullptr, nullptr, nullptr);
    if(!png)
    {
        std::fclose(fp);
        return false;
    }

    png_infop info = png_create_info_struct(png);
    if(!info)
    {
        png_destroy_write_struct(&png, nullptr);
        std::fclose(fp);
        return false;
    }

    if(setjmp(png_jmpbuf(png)))
    {
        png_destroy_write_struct(&png, &info);
        std::fclose(fp);
        return false;
    }

    png_init_io(png, fp);
    png_set_IHDR(png,
                 info,
                 width,
                 height,
                 8,
                 PNG_COLOR_TYPE_RGB,
                 PNG_INTERLACE_NONE,
                 PNG_COMPRESSION_TYPE_DEFAULT,
                 PNG_FILTER_TYPE_DEFAULT);
    png_write_info(png, info);

    std::vector<uint8_t> row(width * 3);
    for(int y = 0; y < height; y++)
    {
        for(int x = 0; x < width; x++)
        {
            const uint8_t* px = &pixels[(y * width + x) * 4];
            row[x * 3 + 0]    = px[2];
            row[x * 3 + 1]    = px[1];
            row[x * 3 + 2]    = px[0];
        }
        png_write_row(png, row.data());
    }

    png_write_end(png, nullptr);
    png_destroy_write_struct(&png, &info);
    std::fclose(fp);
    return true;
}

extern "C"
{
    const char* nvim_screenshot(const char* window_title,
                                const char* save_dir)
    {
        static std::string result;
        result.clear();

        Display* display = XOpenDisplay(nullptr);
        if(!display)
        {
            result = "ERROR: cannot open display";
            return result.c_str();
        }

        Window root   = DefaultRootWindow(display);
        Window target = root;

        if(window_title && std::strlen(window_title) > 0)
        {
            std::function<Window(Window)> find_window =
                [&](Window w) -> Window
            {
                char* name = nullptr;

                if(XFetchName(display, w, &name) && name)
                {
                    std::string wname(name);
                    XFree(name);

                    if(wname.find(window_title) !=
                       std::string::npos)
                        return w;
                }

                Window       root_r, parent;
                Window*      children = nullptr;
                unsigned int n        = 0;

                if(XQueryTree(
                       display, w, &root_r, &parent, &children, &n))
                {
                    for(unsigned int i = 0; i < n; i++)
                    {
                        Window found = find_window(children[i]);
                        if(found != None)
                        {
                            if(children)
                                XFree(children);
                            return found;
                        }
                    }

                    if(children)
                        XFree(children);
                }

                return None;
            };

            Window found = find_window(root);
            if(found != None)
                target = found;
        }

        XWindowAttributes attrs;
        if(!XGetWindowAttributes(display, target, &attrs))
        {
            XCloseDisplay(display);
            result = "ERROR: XGetWindowAttributes failed";
            return result.c_str();
        }

        int width  = attrs.width;
        int height = attrs.height;

        if(width <= 0 || height <= 0)
        {
            XCloseDisplay(display);
            result = "ERROR: invalid window size";
            return result.c_str();
        }

        XImage* image = XGetImage(display,
                                  target,
                                  0,
                                  0,
                                  width,
                                  height,
                                  AllPlanes,
                                  ZPixmap);
        if(!image)
        {
            XCloseDisplay(display);
            result = "ERROR: XGetImage failed";
            return result.c_str();
        }

        std::vector<uint8_t> pixels(width * height * 4);
        for(int y = 0; y < height; y++)
        {
            for(int x = 0; x < width; x++)
            {
                unsigned long px  = XGetPixel(image, x, y);
                int           idx = (y * width + x) * 4;

                pixels[idx + 0] = (px) & 0xFF;
                pixels[idx + 1] = (px >> 8) & 0xFF;
                pixels[idx + 2] = (px >> 16) & 0xFF;
                pixels[idx + 3] = 0xFF;
            }
        }

        XDestroyImage(image);
        XCloseDisplay(display);

        std::string path = build_output_path(save_dir);
        if(path.empty())
        {
            result = "ERROR: failed to build output path";
            return result.c_str();
        }

        if(!write_png(path, width, height, pixels))
        {
            result = "ERROR: failed to write PNG";
            return result.c_str();
        }

        result = path;
        return result.c_str();
    }
}
