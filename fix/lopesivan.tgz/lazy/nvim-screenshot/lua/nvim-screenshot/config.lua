---@class ScreenshotConfig
---@field save_dir string
---@field window_title string
---@field notify boolean
---@field lib_path string|nil
---@field delay_ms integer

local M = {}

---@type ScreenshotConfig
M.defaults = {
    save_dir     = "~/screenshots",
    window_title = "nvim",
    notify       = true,
    lib_path     = nil,
    delay_ms     = 120,
}

---@param opts ScreenshotConfig|nil
---@return ScreenshotConfig
function M.resolve(opts)
    local cfg = vim.tbl_deep_extend("force", M.defaults, opts or {})

    -- normaliza save_dir
    cfg.save_dir = vim.fn.expand(cfg.save_dir)

    -- validações
    assert(type(cfg.save_dir) == "string", "nvim-screenshot: save_dir deve ser string")
    assert(type(cfg.window_title) == "string", "nvim-screenshot: window_title deve ser string")
    assert(type(cfg.notify) == "boolean", "nvim-screenshot: notify deve ser boolean")
    assert(cfg.lib_path == nil or type(cfg.lib_path) == "string",
        "nvim-screenshot: lib_path deve ser string ou nil")
    assert(type(cfg.delay_ms) == "number", "nvim-screenshot: delay_ms deve ser number")
    return cfg
end

return M
