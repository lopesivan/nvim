local M = {}

local DEBUG = false

local function log(msg)
    if DEBUG then
        vim.notify("[nvim-screenshot] " .. msg)
    end
end

local ffi = require("ffi")
local lib = nil

ffi.cdef [[
  const char* nvim_screenshot(const char* window_title, const char* save_dir);
]]

local function plugin_root()
    local this_file = debug.getinfo(1, "S").source:sub(2)
    return this_file:match("(.*/)lua/")
end

---@param cfg ScreenshotConfig
function M.load(cfg)
    if lib then
        return lib
    end

    local candidates = {}

    if cfg.lib_path and cfg.lib_path ~= "" then
        table.insert(candidates, cfg.lib_path)
    end

    local root = plugin_root()
    if root then
        local local_so = root .. "nvim_screenshot.so"
        log("Tentando carregar: " .. local_so)
        table.insert(candidates, local_so)
    end

    local user_so = vim.fn.expand("~/.local/lib/nvim_screenshot.so")
    log("Tentando carregar: " .. user_so)
    table.insert(candidates, user_so)

    local errors = {}

    for _, path in ipairs(candidates) do
        if vim.fn.filereadable(path) == 1 then
            local ok, result = pcall(ffi.load, path)
            if ok then
                lib = result
                log("Biblioteca carregada: " .. path)
                return lib
            else
                table.insert(errors, "ffi.load falhou em " .. path .. " -> " .. tostring(result))
            end
        else
            table.insert(errors, "arquivo não encontrado: " .. path)
        end
    end

    error("nvim-screenshot: falha ao carregar biblioteca:\n" .. table.concat(errors, "\n"))
end

return M
