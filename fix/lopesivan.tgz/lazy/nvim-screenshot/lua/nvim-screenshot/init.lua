local M = {}

---@type ScreenshotConfig
M.config = require("nvim-screenshot.config").resolve()

---@param opts ScreenshotConfig|nil
function M.setup(opts)
    M.config = require("nvim-screenshot.config").resolve(opts)
    vim.fn.mkdir(M.config.save_dir, "p")
end

function M.screenshot(title)
    local ffi_mod = require("nvim-screenshot.ffi")
    local ffi = require("ffi")

    local ok, lib = pcall(ffi_mod.load, M.config)
    if not ok then
        vim.notify(lib, vim.log.levels.ERROR)
        return
    end

    local win_title = title or M.config.window_title

    -- vim.cmd("redraw")
    -- OR using the newer table-call syntax:
    vim.cmd.redraw()
    vim.cmd.redrawstatus()

    -- vim.cmd("redraw!")
    -- OR using the newer table-call syntax:
    -- vim.cmd.redraw({ bang = true })

    --[[
vim.defer_fn({fn}, {timeout})                                    *vim.defer_fn*
    Adia a chamada de {fn} até que {timeout} ms se passem. Use para fazer um
    temporizador de uma só vez que chama {fn}.

    Observação: O {fn} é |schedule_wrap|ped automaticamente, então as funções
    da API são seguras para serem chamadas.

    Parâmetros:
        {fn}        Callback para chamar quando {timeout} expirar
        {timeout}   Tempo em ms para esperar antes de chamar {fn}

    Retorna:
        |vim.loop|.new_timer() object
    --]]
    vim.defer_fn(function()
        local result = ffi.string(lib.nvim_screenshot(win_title, M.config.save_dir))

        if result:sub(1, 5) == "ERROR" then
            vim.notify("Screenshot falhou: " .. result, vim.log.levels.ERROR)
            return
        end

        if M.config.notify then
            vim.notify("Screenshot salvo: " .. result, vim.log.levels.INFO)
        end
    end, M.config.delay_ms)
end

function M.build()
    -- resolve o diretório raiz do plugin a partir deste arquivo
    local this_file = debug.getinfo(1, "S").source:sub(2)
    local plugin_root = this_file:match("(.*/)lua/")

    vim.notify("Compilando nvim_screenshot.so...", vim.log.levels.INFO)

    vim.fn.jobstart({ "make", "-C", plugin_root }, {
        on_exit = function(_, code)
            if code == 0 then
                vim.notify("nvim_screenshot.so compilada com sucesso!", vim.log.levels.INFO)
            else
                vim.notify("Falha na compilação. Veja :messages", vim.log.levels.ERROR)
            end
        end,
        on_stderr = function(_, data)
            if data then
                local msg = table.concat(data, "\n"):gsub("^%s+", ""):gsub("%s+$", "")
                if msg ~= "" then
                    vim.notify(msg, vim.log.levels.WARN)
                end
            end
        end,
    })
end

return M
