
if vim.g.nvim_screenshot_loaded then return end
vim.g.nvim_screenshot_loaded = true

vim.api.nvim_create_user_command("Screenshot", function(opts)
  require("nvim-screenshot").screenshot(opts.args ~= "" and opts.args or nil)
end, {
  nargs = "?",
  desc  = "Tira screenshot do Neovim e salva em save_dir",
})

vim.api.nvim_create_user_command("ScreenshotBuild", function()
  require("nvim-screenshot").build()
end, {
  desc = "Compila nvim_screenshot.so via Makefile",
})

