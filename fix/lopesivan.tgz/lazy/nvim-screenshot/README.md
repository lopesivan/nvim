# nvim-screenshot

Plugin para Neovim que permite capturar screenshots de janelas X11 diretamente do editor, utilizando uma integração nativa em C++ via LuaJIT FFI.

O plugin pode capturar:

- A janela do próprio Neovim
- Qualquer outra janela (Chrome, Firefox, etc.) pelo título
- A tela inteira (fallback automático)

---

## ✨ Features

- 📸 Screenshot de janelas via X11
- ⚡ Integração nativa (C++ + libX11 + libpng)
- 🧠 Busca de janela por título (WM_NAME / _NET_WM_NAME)
- 🪶 Leve e sem dependências pesadas
- 🔧 Compilação automática via `make`
- ⏱ Delay configurável para evitar capturar cmdline do Neovim
- 🖥 Funciona com qualquer window manager baseado em X11 (ex: i3wm)

---

## ⚠️ Requisitos

Este plugin **só funciona em X11**.

✔ Compatível:
- i3wm
- Openbox
- XFCE
- KDE (modo X11)
- GNOME (modo X11)

❌ Não compatível:
- Wayland puro (sem XWayland)

### Dependências

Instale no seu sistema:

```bash
sudo apt install libx11-dev libpng-dev
````

ou equivalente na sua distro.

---

## 🚀 Instalação (Lazy.nvim)

```lua
return {
    {
        "lopesivan/nvim-screenshot",

        cmd = {
            "Screenshot",
            "ScreenshotBuild"
        },

        build = "make",

        opts = {
            save_dir     = "/workspace/obs/screenshot",
            window_title = "nvim",
            notify       = true,
            lib_path     = nil,
            delay_ms     = 120,
        },

        config = function(_, opts)
            require("nvim-screenshot").setup(opts)
        end,
    },
}
```

---

## 🔧 Primeira execução

Após instalar, compile a biblioteca:

```vim
:ScreenshotBuild
```

Isso irá gerar:

```
nvim_screenshot.so
```

---

## 📸 Uso

### Screenshot do Neovim

```vim
:Screenshot
```

### Screenshot de outra janela

```vim
:Screenshot Chrome
```

ou:

```vim
:Screenshot Firefox
```

ou qualquer substring do título da janela:

```vim
:Screenshot YouTube
```

---

## 🔍 Como descobrir o nome da janela

Use no terminal:

```bash
xprop | grep WM_NAME
```

ou:

```bash
xprop | grep _NET_WM_NAME
```

Depois clique na janela desejada.

---

## ⚙️ Configuração

```lua
opts = {
    save_dir     = "/workspace/obs/screenshot",
    window_title = "nvim",
    notify       = true,
    lib_path     = nil,
    delay_ms     = 120,
}
```

### Opções

| Opção          | Tipo   | Descrição                                       |
| -------------- | ------ | ----------------------------------------------- |
| `save_dir`     | string | Diretório onde os PNGs serão salvos             |
| `window_title` | string | Janela padrão (quando não passa argumento)      |
| `notify`       | bool   | Mostra notificação após salvar                  |
| `lib_path`     | string | Caminho manual da `.so` (opcional)              |
| `delay_ms`     | number | Delay antes da captura (evita cmdline aparecer) |

---

## 🧠 Como funciona

1. Lua chama função via FFI
2. C++ usa X11 (`XGetImage`) para capturar pixels
3. libpng salva imagem
4. Caminho é retornado ao Neovim

Busca de janelas usa:

* `WM_NAME`
* `_NET_WM_NAME` (UTF-8)

---

## ⚠️ Observações importantes

* O título da janela pode mudar (ex: abas do Chrome)
* Se não encontrar a janela, o plugin captura a tela inteira
* Em i3wm funciona perfeitamente (X11 puro)

---

## 🧪 Debug

Se algo não funcionar:

```vim
:messages
```

ou no terminal:

```bash
ldd nvim_screenshot.so

lua print(vim.inspect(require("nvim-screenshot").config))

lua print(vim.inspect(require("local-nvim-screenshot").config))
```
---

## 💡 Ideias futuras

* Seleção de área (tipo screenshot interativo)
* Clipboard (xclip / wl-copy)
* Integração com Telescope
* Suporte Wayland (complexo)

---

## 📄 Licença

MIT

---

## 👨‍💻 Autor

Ivan Lopes

