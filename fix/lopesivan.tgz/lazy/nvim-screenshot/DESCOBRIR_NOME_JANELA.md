Você precisa descobrir **qual string aparece no título da
janela do Chrome**.

Vou te dar os métodos mais diretos no Linux/X11.

---

# ✔️ Método 1 (o melhor): `xprop`

No terminal:

```bash
xprop | grep WM_NAME
```

Depois:

👉 o cursor vira um “+”
👉 clique na janela do Chrome

Vai aparecer algo como:

```text
WM_NAME(STRING) = "YouTube - Google Chrome"
```

ou:

```text
WM_NAME(STRING) = "ChatGPT - Google Chrome"
```

---

## Como usar no plugin

Você não precisa do nome completo — seu código usa:

```cpp
wname.find(window_title)
```

Então basta um trecho:

```vim
:Screenshot Chrome
```

ou:

```vim
:Screenshot YouTube
```

ou:

```vim
:Screenshot ChatGPT
```

---

# ✔️ Método 2: `wmctrl`

Liste todas as janelas:

```bash
wmctrl -l
```

Exemplo de saída:

```text
0x04800003  0 host YouTube - Google Chrome
0x03e00007  0 host Neovim
```

Aqui você pode usar:

```vim
:Screenshot Chrome
```

---

# ✔️ Método 3: `xwininfo`

```bash
xwininfo
```

Clique na janela e veja:

```text
xwininfo: Window id: 0x4800003 "YouTube - Google Chrome"
```

---

# ✔️ Método 4 (mais direto ainda)

```bash
xprop WM_NAME
```

e clique na janela.

---

# ⚠️ Observação importante

O Chrome muda o título dinamicamente:

* Aba ativa muda o nome
* Ex:

  * "YouTube - Google Chrome"
  * "Gmail - Google Chrome"
  * "Stack Overflow - Google Chrome"

👉 então o melhor padrão é usar:

```vim
:Screenshot Chrome
```

ou até:

```vim
:Screenshot google
```

(se quiser algo mais genérico)

---

# 💡 Dica avançada

Se quiser ser mais preciso no futuro, você pode trocar:

```cpp
wname.find(window_title)
```

por busca em:

* `WM_CLASS` (mais estável)

Exemplo:

```bash
xprop WM_CLASS
```

Chrome normalmente retorna:

```text
WM_CLASS(STRING) = "google-chrome", "Google-chrome"
```

👉 Isso **não muda com a aba**

---

# ✔️ Resumo

Para descobrir o nome da janela:

```bash
xprop | grep WM_NAME
```

Depois use no Neovim:

```vim
:Screenshot Chrome
```

---


