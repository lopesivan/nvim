local h = require("null-ls.helpers")
local methods = require("null-ls.methods")

local FORMATTING = methods.internal.FORMATTING
local astyle_config = ".astylerc"

-- Função para verificar a existência do arquivo .astylerc no diretório raiz do projeto
local function has_astylerc(utils)
    return utils.root_has_file(astyle_config)
end

return h.make_builtin({
    name = "astyle",
    meta = {
        url = "http://astyle.sourceforge.net/",
        description =
        [[Artistic Style is a source code indenter, formatter, and beautifier for the C, C++, C++/CLI, Objective‑C, C# and Java programming languages. This formatter works well for [Arduino](https://www.arduino.cc/) project files and is the same formatter used in the Arduino IDE.]],
    },
    method = FORMATTING,
    filetypes = { "arduino", "c", "cpp", "cs", "java" },
    generator_opts = {
        command = "astyle",
        args = function(params)
            local args = { "--quiet" }
            -- Adiciona a opção --options=.astylerc se o arquivo existir
            if has_astylerc(require("null-ls.utils").make_conditional_utils()) then
                table.insert(args, 1, string.format("--options=%s", astyle_config))
            else
                vim.notify(
                    "[astyle] .astylerc not found",
                    vim.log.levels.ERROR
                )
            end
            return args
        end,

        to_stdin = true,
    },
    factory = h.formatter_factory,
})
